using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }



    public IActionResult Index(string name, string email)
    {
        
        _logger.LogInformation("Запрос на страницу Index с параметрами: Name = {Name}, Email = {Email}, name, email,"?? "Не указано");

        if(!string.IsNullOrEmpty(email))
        {
            ViewBag.Email = email;
        }
        else
        {
            ViewBag.Email = "Ваша почта";
        }

        return ViewBag();
    }
}